import { Routes, Route } from "react-router-dom";
import SSOYA from "./SSOYA";
import Admin from "./Admin";
import RandomOverlay from "./RandomOverlay";

function App() {
  return (
    <Routes>
      <Route path="/" element={<SSOYA />} />
      <Route path="/admin" element={<Admin />} />
      <Route path="/random-overlay" element={<RandomOverlay />} />
    </Routes>
  );
}

export default App;
